package com.model;

import java.io.Serializable;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//name,address,phoneno,email,company name,age,opening balance.


@Entity
@Table(name="Customer")
public class customer implements  Serializable{
	
	@Id
	
	@Column(name="cusId")
	private int cusId;
	
	@Column(name="cusName")
	private String cusName;
	
	@Column(name="cusAddress")
	private String cusAddress;
	
	@Column(name="cusPhoneno")
	private int cusPhoneno;
	
	@Column(name="cusEmail")
	private String cusEmail;
	
	@Column(name="cusCompany")
	private String cusCompany;
	
	@Column(name="cusAge")
	private int cusAge;
	
	@Column(name="cusBalance")
	private int cusBalance;

	public int getCusId() {
		return cusId;
	}

	public void setCusId(int cusId) {
		this.cusId = cusId;
	}

	public String getCusName() {
		return cusName;
	}

	public void setCusName(String cusName) {
		this.cusName = cusName;
	}

	public String getCusAddress() {
		return cusAddress;
	}

	public void setCusAddress(String cusAddress) {
		this.cusAddress = cusAddress;
	}

	public int getCusPhoneno() {
		return cusPhoneno;
	}

	public void setCusPhoneno(int cusPhoneno) {
		this.cusPhoneno = cusPhoneno;
	}

	public String getCusEmail() {
		return cusEmail;
	}

	public void setCusEmail(String cusEmail) {
		this.cusEmail = cusEmail;
	}

	public String getCusCompany() {
		return cusCompany;
	}

	public void setCusCompany(String cusCompany) {
		this.cusCompany = cusCompany;
	}

	public int getCusAge() {
		return cusAge;
	}

	public void setCusAge(int cusAge) {
		this.cusAge = cusAge;
	}

	public int getCusBalance() {
		return cusBalance;
	}

	public void setCusBalance(int cusBalance) {
		this.cusBalance = cusBalance;
	}
	

}
