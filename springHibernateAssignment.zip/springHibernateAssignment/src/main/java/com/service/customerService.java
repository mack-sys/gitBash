package com.service;

import java.util.List;


import com.model.customer;

public interface customerService {

	
	public void addCustomer(customer cus);

	public static List<customer> listCustomer() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static  customer getCustomer(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public static  void deleteCustomer(customer cus) {
		// TODO Auto-generated method stub
		
	}
		
		
	
}
