package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.dao.customerDao;
import com.model.customer;



@Service("customerService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class customerServiceImpl implements customerService {
	
	@Autowired
	private customerDao custDao;
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addCustomer(customer cus)  {
		custDao.addCustomer(cus);
	}

	public List<customer> listCustomer(){
		return custDao.listCustomer();
	}
	
	public customer getCustomer(int id) {
		return custDao.getCustomer(id);
	}
	
	public void deleteCustomer(customer cus) {
		custDao.deleteCustomer(cus);
	}
}
