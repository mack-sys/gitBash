package com.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bean.customerBean;
import com.model.customer;
import com.service.customerService;


@Controller
public class customerController {
	@Autowired
	private customerService cusService;
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveCustomer(@ModelAttribute("command") customerBean cusBean, BindingResult result) {
		customer cus = prepareModel(cusBean);
		cusService.addCustomer(cus);
		return new ModelAndView("redirect:/add");
	}

	@RequestMapping(value="/employees", method = RequestMethod.GET)
	public ModelAndView listEmployees() {
		Map<String, Object> model = new HashMap<String,  Object>();
		model.put("employees", prepareListofBean(customerService.listCustomer()));
		return new ModelAndView("employeesList", model);
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView addEmployee(@ModelAttribute("command")  customerBean cusBean,
			BindingResult result) 
	{
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("employees",  prepareListofBean(customerService.listCustomer()));
		return new ModelAndView("addEmployee", model);
	}
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView welcome() {
		return new ModelAndView("index");
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView editEmployee(@ModelAttribute("command") customerBean cusBean,
			BindingResult result) {
		customerService.deleteCustomer(prepareModel(cusBean));
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("employee", null);
		model.put("employees",  prepareListofBean(customerService.listCustomer()));
		return new ModelAndView("addEmployee", model);
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView deleteEmployee(@ModelAttribute("command")  customerBean cusBean,
			BindingResult result)
	{
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("employee", prepareEmployeeBean(customerService.getCustomer(cusBean.getId())));
		model.put("employees",  prepareListofBean(customerService.listCustomer()));
		return new ModelAndView("addEmployee", model);
	}
	
	
	

	
	
	private customer prepareModel(customerBean cusBean){
		customer cus = new customer();
		cus.setCusName(cusBean.getName());
		cus.setCusAddress(cusBean.getAddress());
		cus.setCusPhoneno(cusBean.getPhoneno());
		cus.setCusEmail(cusBean.getEmail());
		cus.setCusCompany(cusBean.getCompany());
		cus.setCusAge(cusBean.getAge());
		cus.setCusBalance(cusBean.getBalance());
		cus.setCusId(cusBean.getId());
		return cus;

	}
	

	private List<customerBean> prepareListofBean(List<customer> cust){
		List<customerBean> beans = null;
		if(cust != null && !cust.isEmpty()){
			beans = new ArrayList<customerBean>();
			customerBean bean = null;
			for(customer cus : cust){
				bean = new customerBean();
				bean.setName(cus.getCusName());
				bean.setAddress(cus.getCusAddress());
				bean.setPhoneno(cus.getCusPhoneno());
				bean.setEmail(cus.getCusEmail());
				bean.setCompany(cus.getCusCompany());
				bean.setAge(cus.getCusAge());
				bean.setBalance(cus.getCusBalance());
				bean.setId(cus.getCusId());
				beans.add(bean);
			}
		}
		return beans;
	}
	//name,address,phoneno,email,company name,age,opening balance.
	private customerBean prepareEmployeeBean(customer cus){
		customerBean bean = new customerBean();
		bean.setName(cus.getCusName());
		bean.setAddress(cus.getCusAddress());
		bean.setPhoneno(cus.getCusPhoneno());
		bean.setEmail(cus.getCusEmail());
		bean.setCompany(cus.getCusCompany());
		bean.setAge(cus.getCusAge());
		bean.setBalance(cus.getCusBalance());
		bean.setId(cus.getCusId());
		return bean;
	}
}
