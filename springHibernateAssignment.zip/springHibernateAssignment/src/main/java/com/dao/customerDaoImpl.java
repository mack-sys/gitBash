package com.dao;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

import com.model.customer;

@Repository("customerDao")
public class customerDaoImpl implements customerDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void addCustomer(customer cus) {
		sessionFactory.getCurrentSession().saveOrUpdate(cus);
	}

//	@SuppressWarnings("unchecked")
	public List<customer> listCustomer(){
		return (List<customer>) sessionFactory.openSession().createCriteria(customer.class).list();
	}
	
	public customer getCustomer(int id) {
		return (customer) sessionFactory.getCurrentSession().get(customer.class, id);
	}
	
	public void deleteCustomer(customer cus) {
		sessionFactory.getCurrentSession().createQuery("DELETE FROM employee WHERE cuspId = "+cus.getCusId()).executeUpdate();
	}
	
}
