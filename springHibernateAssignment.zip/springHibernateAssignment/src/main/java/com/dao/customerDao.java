package com.dao;

import java.util.List;

import com.model.customer;

public interface customerDao {

	public void addCustomer(customer cus);

	public List<customer> listCustomer();
	
	public customer getCustomer(int empid);
	
	public void deleteCustomer(customer cus);
	
}
